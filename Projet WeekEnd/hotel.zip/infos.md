font : 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;


couleurs :
#fff
#333
#444
#f7c08a
#f7c98a
#f4f4f4
#f6c08a
