Title : Disii Rock'n Grole

##DiSii Band

#menu :
Home
OurStory
Discography
News
Contact

#section 1
New album is out
New EP is out now!
Lorem ipsum, dolor sit amet consectetur adipisicing elit. Unde voluptates sint error nam molestias              architecto, autem consequuntur culpa. Eaque, ullam!
Learn more

#section 2
Spotify
Bandcamp
Soundcloud
Youtube Music

#section 3
Meet the artists
Our Band

Ant Raimbault
Guitar / Vocal

Za Maitre-Jean
Lead Vocal

Tony Tavares
Bass / Vocal

N'rv Guerre
Drums / Percussion

#section 4
News
from the Blog

We are going to Vernon Festival
Introduction Readymade Lorem, ipsum dolor sit amet consectetur adipisicing elit. Praesentium, reiciendis!

The newest member of the band: N'RV
N'RV is born in a drum lorem, ipsum dolor sit amet consectetur adipisicing elit. Praesentium, reiciendis!

White hill festival
Introduction Readymade Lorem, ipsum dolor sit amet consectetur adipisicing elit. Praesentium, reiciendis!

#section 5
New album is out
Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse nihil blanditiis, alias, velit minima corporis optio quaerat sapiente inventore exercitationem laudantium earum impedit recusandae facere.

#section 6
Our Band
Tour dates announced

June 2
Vernon, place du marché
Buy Tickets

June 9
Evreux, Le Tangram
Buy Tickets

June 15
Rouen, Le Zenith
Buy Tickets

#section 7
Like our tunes?
Discography

2020
Cascading HyperText
Details

2022
Responsive mood
Details

#section 7
Like our tunes?
Find our music online

Spotify
Bandcamp
Soundcloud
Youtube Music
